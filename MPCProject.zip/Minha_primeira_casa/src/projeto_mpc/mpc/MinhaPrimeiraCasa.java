//Eduardo Luiz Pontes de Souza - UC19100270
package projeto_mpc.mpc;

public class MinhaPrimeiraCasa {

	private String nome;

	public MinhaPrimeiraCasa(String nome) {
		this.nome = nome;
	}

	MinhaPrimeiraCasa() {

	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}
}